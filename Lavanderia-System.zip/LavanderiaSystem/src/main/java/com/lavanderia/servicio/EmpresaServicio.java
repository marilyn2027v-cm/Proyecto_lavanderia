package com.lavanderia.servicio;

import com.lavanderia.dao.EmpresaDAO;
import com.lavanderia.modelo.Empresa;

public class EmpresaServicio {

    private EmpresaDAO empresaDAO;

    public EmpresaServicio() {
        this.empresaDAO = new EmpresaDAO();
    }

    public boolean guardarEmpresa(String ruc, String razonSocial, String nombreComercial, String ubigeo,
                                  String apPaterno, String apMaterno, String nombres,
                                  String dni, String celular, String correo) {

        Empresa emp = new Empresa();
        emp.setRuc(ruc);
        emp.setRazonSocial(razonSocial);
        emp.setNombreComercial(nombreComercial);
        emp.setUbigeo(ubigeo);
        emp.setApPaterno(apPaterno);
        emp.setApMaterno(apMaterno);
        emp.setNombres(nombres);
        emp.setDni(dni);
        emp.setCelular(celular);
        emp.setCorreo(correo);

        return empresaDAO.registrarEmpresa(emp);
    }
}