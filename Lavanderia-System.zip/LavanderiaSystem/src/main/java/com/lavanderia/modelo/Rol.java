package com.lavanderia.modelo;

import java.util.Date;

public class Rol {
    private int idRol;
    private String nombre;
    private boolean estado;
    private Date fechaCreacion;

    public Rol() {}

    public Rol(int idRol, String nombre, boolean estado, Date fechaCreacion) {
        this.idRol = idRol;
        this.nombre = nombre;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
    }

    public int getIdRol() { return idRol; }
    public void setIdRol(int idRol) { this.idRol = idRol; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}