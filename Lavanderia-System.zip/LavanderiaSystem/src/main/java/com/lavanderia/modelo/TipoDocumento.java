package com.lavanderia.modelo;

import java.util.Date;

public class TipoDocumento {
    private int idTipoDocumento;
    private Integer idEmpresa;
    private String nombre;
    private String nombreLargo;
    private String codigoInterno;
    private boolean estado;
    private Date fechaCreacion;

    public TipoDocumento() {}

    public int getIdTipoDocumento() { return idTipoDocumento; }
    public void setIdTipoDocumento(int idTipoDocumento) { this.idTipoDocumento = idTipoDocumento; }
    public Integer getIdEmpresa() { return idEmpresa; }
    public void setIdEmpresa(Integer idEmpresa) { this.idEmpresa = idEmpresa; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getNombreLargo() { return nombreLargo; }
    public void setNombreLargo(String nombreLargo) { this.nombreLargo = nombreLargo; }
    public String getCodigoInterno() { return codigoInterno; }
    public void setCodigoInterno(String codigoInterno) { this.codigoInterno = codigoInterno; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}