package com.lavanderia.modelo;

import java.util.Date;

public class Sucursal {
    private int idSucursal;
    private int idEmpresa;
    private String nombre;
    private String direccion;
    private String telefono;
    private boolean estado;
    private Integer idUsuarioCreacion;
    private Date fechaCreacion;

    public Sucursal() {}

    public int getIdSucursal() { return idSucursal; }
    public void setIdSucursal(int idSucursal) { this.idSucursal = idSucursal; }
    public int getIdEmpresa() { return idEmpresa; }
    public void setIdEmpresa(int idEmpresa) { this.idEmpresa = idEmpresa; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
    public Integer getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(Integer idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }
    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}