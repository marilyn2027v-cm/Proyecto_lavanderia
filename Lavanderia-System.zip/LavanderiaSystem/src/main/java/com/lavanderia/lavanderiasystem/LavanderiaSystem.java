/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.lavanderia.lavanderiasystem;

/**
 *
 * @author usser
 */
public class LavanderiaSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
