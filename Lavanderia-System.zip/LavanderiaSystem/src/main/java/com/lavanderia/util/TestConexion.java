package com.lavanderia.util;

import java.sql.Connection;
import java.sql.SQLException;

public class TestConexion {
    public static void main(String[] args) {
        System.out.println("Iniciando prueba de conexion a SQL Server...");
        
        try (Connection cn = ConexionBD.getConexion()) {
            if (cn != null) {
                System.out.println("==========================================");
                System.out.println("¡CONEXION EXITOSA A SQL SERVER!");
                System.out.println("Base de datos: Lavanderia_net conectada.");
                System.out.println("==========================================");
            }
        } catch (SQLException e) {
            System.err.println("==========================================");
            System.err.println("ERROR DE CONEXION: " + e.getMessage());
            System.err.println("==========================================");
        }
    }
}