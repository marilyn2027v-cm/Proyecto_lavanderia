package com.lavanderia.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String SERVER = "localhost"; // Usamos localhost para conexion local directa
    private static final String PORT = "1433"; 
    private static final String DATABASE = "Lavanderia_net"; 
    private static final String USER = "Lavanderia_net"; 
    private static final String PASSWORD = "Lavanderia_net_26"; 

    private static final String URL = "jdbc:sqlserver://" + SERVER + ":" + PORT + 
            ";databaseName=" + DATABASE + 
            ";encrypt=true;trustServerCertificate=true;";

    public static Connection getConexion() throws SQLException {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Error: Driver no encontrado. " + e.getMessage());
        }
    }
}