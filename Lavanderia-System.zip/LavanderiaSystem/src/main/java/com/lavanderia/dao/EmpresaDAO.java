package com.lavanderia.dao;

import com.lavanderia.modelo.Empresa;
import com.lavanderia.util.ConexionBD;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class EmpresaDAO {

    public boolean registrarEmpresa(Empresa emp) {
        String sql = "[gen].[sp_RegistrarEmpresa]";

        try (Connection cn = ConexionBD.getConexion();
             CallableStatement cs = cn.prepareCall(sql)) {

            cs.setString(1, emp.getRuc());
            cs.setString(2, emp.getRazonSocial());
            cs.setString(3, emp.getNombreComercial());
            cs.setString(4, emp.getUbigeo());
            cs.setString(5, emp.getApPaterno());
            cs.setString(6, emp.getApMaterno());
            cs.setString(7, emp.getNombres());
            cs.setString(8, emp.getDni());
            cs.setString(9, emp.getCelular());
            cs.setString(10, emp.getCorreo());

            return cs.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error en EmpresaDAO: " + e.getMessage());
            return false;
        }
    }
}